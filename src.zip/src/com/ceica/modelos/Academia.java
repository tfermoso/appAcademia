package com.ceica.modelos;

import java.util.Arrays;

public class Academia {
    private  String nombre;
    private Alumno[] alumnos;


    public Academia(String nombre, int numero_alumnos){
        this.nombre=nombre;
        this.alumnos=new Alumno[numero_alumnos];
    }



    @Override
    public String toString() {
        return "Academia{" +
                "nombre='" + nombre + '\'' +
                ", alumnos=" + Arrays.toString(alumnos) +
                '}';
    }
}
