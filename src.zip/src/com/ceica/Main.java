package com.ceica;


import com.ceica.modelos.Academia;
import com.ceica.modelos.Alumno;

public class Main {
    public static void main(String[] args) {
        Academia academia;
        if(args.length>1){
            String nombre_academia=args[0];
            int numero_alumnos;
            try{
                numero_alumnos= Integer.parseInt(args[1]);
            }catch (NumberFormatException e){
                System.out.println("Número no válido");
                numero_alumnos=20;
            }

            academia=new Academia(nombre_academia,numero_alumnos);
        }else{
            academia=new Academia("CEICA",20);
        }

        System.out.println(academia.toString());

    }
}